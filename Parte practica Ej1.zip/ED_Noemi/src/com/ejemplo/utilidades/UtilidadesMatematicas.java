package com.ejemplo.utilidades;

public class Noe_ED {
	private int Nombre;

	public Persona(int NombrePersona) {
		this.Nombre = Nombre;
		
 public void invertCadena (String cadena) {
	 if (cadena == null) {
		 throw new  IllegalArgumentException ("Nombre");
			
		 System.out.println("Hola" + Nombre+ "bienvenido a la generacion del futuro.");
	
}
